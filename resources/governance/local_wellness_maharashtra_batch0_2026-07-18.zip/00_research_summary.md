# Local Wellness Maharashtra Governance Dataset — Batch 0 Research Summary

**Batch ID:** `MH-LW-BATCH0-2026-07-18`  
**Generated/retrieved at:** `2026-07-18T12:21:03+05:30` (Asia/Kolkata)  
**Schema version:** `0.1.0`  
**Scope completed:** Batch 0 source registry, source-date review, count reconciliation and discrepancy register. Batch 1 has begun only with a non-routable baseline for Maharashtra and its 36 districts.  
**Operational routing records activated:** **0**  
**Automatic promotions:** **None. No records were automatically promoted.**

## Evidence policy and date semantics

Only government-operated sources were used. Search was used only to discover official pages; search-result snippets were not used as evidence. A page's presence online, copyright year, or “last reviewed” date is **not** treated as a data effective date. The source registry separates retrieval time, publication/source-as-of time, and page review time. Missing effective dates are retained as issues rather than guessed.

The initial state/district rows are directly supported by the official Maharashtra LGD village directory, but that page exposes no snapshot effective date. They are therefore marked `source_verified`, `temporal_currency_status=undated_official_snapshot`, and `routable=false`; they are staging records, not routing authority.

## Batch 0 count reconciliation

| Metric | DMA | State Election Commission | LGD generated report | MahaBhumi | Result |
|---|---:|---:|---:|---:|---|
| Districts | — | 36 | 36 | 36 | Agreement among reporting sources |
| Talukas / subdistricts | — | — | 358 | 358 | Agreement |
| Villages | — | — | 44,857 | 44,857 | Agreement |
| Municipal corporations | 29 | 29 | not class-split | 27 | **Conflict** |
| Municipal councils | combined below | 247 | not class-split | 241 | **Conflict** |
| Nagar Panchayats | combined below | 147 | not class-split | 131 | **Conflict** |
| Councils + Nagar Panchayats | 395 | 394 (derived) | not class-split | 372 (derived) | **Conflict** |
| Urban local bodies excluding cantonments | 424 | 423 (derived) | 422 | 399 (derived) | **Conflict** |
| District Panchayats / Zilla Parishads | — | 34 | 34 | — | Agreement |
| Intermediate Panchayats / Panchayat Samitis | — | 351 | 351 | — | Agreement |
| Village / Gram Panchayats | — | 27,782 | 28,044 | 27,894 | **Conflict** |
| Cantonment boards | — | — | 7 | 7 | Agreement; separately classified |

“Derived” values are arithmetic combinations of source-published component counts and are labeled as such in `02_source_discrepancies.csv`. No source was selected merely because its value was larger, newer, or on a recently reviewed page.

## Initial Batch 1 extraction

- `03_states.csv`: 1 Maharashtra record, LGD code 27.
- `04_districts.csv`: 36 district records with official LGD codes, bilingual names, source-reported Census codes and source-reported taluka/village counts where present.
- `05_talukas.csv`: schema only; zero records. A reliable statewide taluka export was not obtained in this batch.
- `25_villages.csv`: supplemental statewide-compatible schema only; zero records.
- Mumbai's source row omits taluka/village counts; Palghar's source row omits Census codes. The blanks are preserved and logged.

## Batch 1 extraction plan

1. Obtain an authorized LGD Maharashtra export for **all districts** and **all subdistricts of a state**, preferably through the OGD API/ZIP; otherwise use the CAPTCHA-protected LGD download interface with a human operator. No CAPTCHA bypass is permitted.
2. Save every raw file, capture the report/resource identifier and generated timestamp, and calculate SHA-256 before transformation.
3. Parse codes as strings, preserve English/local names and raw rows, and retain source-effective dates or modification versions.
4. Cross-check the state/district/taluka hierarchy against MahaBhumi without forcing agreement. Create a discrepancy row for every code, parent, name or count mismatch.
5. Validate expected observations (not hard-coded truth): one state; sources currently agree on 36 districts, 358 talukas/subdistricts and 44,857 villages. A mismatch triggers review, not silent correction.
6. Promote only source-verified records with complete identifiers and parents. Renames and aliases require official notification or explicit official directory evidence.
7. Keep all hierarchy records non-routable until local-body, ward/office and routing evidence are independently complete.

The detailed acceptance gates and field mapping are in `23_batch1_extraction_plan.md`.

## Validation results

| Validation | Result |
|---|---|
| Duplicate official codes | 0 |
| Duplicate normalized district names under the same parent | 0 |
| Missing parents | 0 |
| Missing state/district identifiers | 0 |
| Malformed source URLs | 0 syntactic failures |
| Placeholder entity names | 0 |
| Malformed phone/email and placeholder contacts | No contact records to test |
| Conflicting identifiers inside staged hierarchy | 0; aggregate/classification conflicts remain quarantined |
| Stale hierarchy verification dates | 0 |
| Stale source-content observations | 5 |
| Overlapping officer assignments/contact versions | No records to test |
| Invalid/self-intersecting geometry | No features to test; empty FeatureCollection parses |
| Active ward overlaps/gaps | Not applicable; no official geometry extracted |
| Routing records without evidence | 0; no routing rows |
| Asset routes without ownership evidence | 0; no asset routes |
| Active populated records with non-approved verification states | 0 |
| Unresolved discrepancy groups | 6 groups / 17 observations |

Full machine-readable results are in `24_validation_report.csv`.

## Batch completion metrics

| Measure | Count / result |
|---|---:|
| Primary evidence/hierarchy records extracted | 92 |
| Primary records source-verified | 65 |
| Primary records unverified | 5 |
| Primary records stale | 5 |
| Primary records conflicting | 17 |
| Source observations registered | 38 |
| Source observations source-verified | 28 |
| Source observations unverified | 5 |
| Source observations stale | 5 |
| Count discrepancy observations | 17 |
| Discrepancy groups | 6 |
| Initial hierarchy records extracted | 37 |
| Initial hierarchy records source-verified | 37 |
| Initial hierarchy records unverified | 0 |
| Routing records | 0 |
| Data issues logged | 21 |
| Evidence records quarantined from operational use | 27 |

### Missing, inaccessible or incomplete sources

Materially incomplete in this environment: Gram Manchitra usable GIS content; the Government of Maharashtra portal direct fetch; BMC administration iView content; BMC GIS MapServer metadata; MJP Who's Who full assignment review; OGD resource payload access; and direct LGD export generation without the required authorized CAPTCHA step.

### Recommended human review

Priority review should identify the entity-level cause of the 424/423/422/399 urban-body divergence; reconcile the three Gram Panchayat totals; acquire and hash LGD district/taluka exports; resolve the MJP email conflict; verify current PMC complaint channels on `pmc.gov.in`; and retry the BMC GIS endpoint before any layer or ownership assertion.

## Promotion statement

The one-page recommendation is in `22_batch0_promotion_recommendation.md`. The only records recommended as **safe to stage** are the 1 state and 36 district identity/code rows, with `routable=false` and explicit undated-snapshot caveats. No officer, contact, ward, geometry, asset, ownership or routing record is recommended for production. **No records were automatically promoted.**
