# Batch 0 Promotion Recommendation — Local Wellness Maharashtra

**Batch:** `MH-LW-BATCH0-2026-07-18`  
**Prepared at:** `2026-07-18T12:21:03+05:30` (Asia/Kolkata)  
**Decision principle:** staging is not production routing. No automated promotion was performed.

## Safe to stage

**37 non-routable hierarchy records:** Maharashtra (LGD code 27) and 36 districts with official LGD codes and bilingual names from the Maharashtra LGD village directory. Stage only as a baseline for reconciliation. Keep `routable=false`; retain `temporal_currency_status=undated_official_snapshot`; do not use the page's online availability or 2023 copyright as evidence of currentness.

**28 source-registry observations:** accessible official sources whose existence/content was directly reviewed. This recommendation applies only to the evidence registry, not to all facts or channels displayed on those sources.

## Potentially safe after human review

- District-level Census codes and reported taluka/village counts after comparison with a generated, hashed LGD export.
- Official municipal domains after full coverage reconciliation between DMA, IGOD, district and municipal sources.
- Public grievance channels only after current availability, scope and delivery-approval review; public display alone does not authorize automated delivery.
- BMC Assistant Municipal Commissioner assignments after versioned extraction, vacancy/charge handling and assignment-order checks.

## Conflicting

Six discrepancy groups remain open: statewide ULB total, municipal corporations, combined councils/Nagar Panchayats, municipal councils, Nagar Panchayats and village/Gram Panchayats. All 17 observations remain `conflicting` and quarantined. The MJP contact page also contains two conflicting email addresses.

## Incomplete

Talukas; villages; local bodies; wards; ward boundaries; departments; offices; durable roles; officers; assignments; contact versions; utilities; emergency contacts; routing references; assets; and ownership versions are not populated. BMC GIS, Gram Manchitra and several dynamic directories were unavailable or incomplete in this environment.

## Prohibited from routing

- Every placeholder, unverified, conflicting or stale record.
- The undated/legacy PMC CARE booklet as a live-channel authority.
- Stale MJP contacts and the stale PWD grievance page without re-verification.
- Estimated or screenshot-derived boundaries.
- Inferred emails, phones, officer names, asset ownership or responsibility.
- Any category-only routing rule without jurisdiction/asset-owner evidence and a verified safe fallback.

**Recommendation:** stage the 37 hierarchy identity records only. Route **zero** complaints from this batch. **No records were automatically promoted.**
