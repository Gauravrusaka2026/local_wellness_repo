# Batch 1 Extraction Plan — Maharashtra State, Districts and Talukas

**Prepared:** `2026-07-18T12:21:03+05:30` (Asia/Kolkata)  
**Primary authority:** Local Government Directory (LGD)  
**Cross-check authority:** Maharashtra MahaBhumi LGD village directory  
**Current baseline:** 1 state and 36 districts staged; 0 talukas promoted or staged.

## Acquisition sequence

1. Use the OGD LGD catalogue's official API/ZIP where a Maharashtra resource can be obtained with a stable resource identifier. Record catalogue date separately from resource generation/effective date.
2. If the OGD payload is unavailable, an authorized human operator uses the LGD Download Directory for:
   - All Districts of a State → Maharashtra;
   - All Sub-Districts of a State → Maharashtra;
   - Download All Entities of State, where useful for parent mapping;
   - XLS preferred, HTML/PDF retained for independent visual verification.
3. Do not bypass CAPTCHA. Save raw downloads unchanged under a dated source directory and compute SHA-256 before parsing.
4. Capture report generation timestamp, file name, source URL, selected criteria, resource/report identifier and operator notes.

## Transform and versioning

- Treat official codes as strings and stable identifiers where supplied.
- Preserve raw English and Marathi values, whitespace/spelling anomalies and all source columns.
- Normalize names only into separate fields; never replace raw values.
- Maintain effective_from/effective_to when present. A later record closes, rather than overwrites, a prior version.
- Record renames/aliases only from official notifications/directories. Do not infer legacy names.
- Model subdistrict/taluka terminology explicitly; do not assume every administrative subdistrict is interchangeable with another program's block or Panchayat Samiti.

## Reconciliation

- Cross-check state code 27 and every district/taluka code, name and parent against MahaBhumi.
- Sources presently agree on 36 districts and 358 talukas/subdistricts; these are comparison expectations, not forced totals.
- Any mismatch creates `conflicting` observations in `02_source_discrepancies.csv` and an issue in `20_data_issues.csv`.
- Preserve Mumbai/Palghar missing source fields until an official export supplies them.

## Acceptance gates

A hierarchy row is `source_verified` only when it has an official identifier, name, parent, exact source URL, retrieval timestamp, raw value, normalized value, source record identifier and extraction method. An active row with missing code/parent, conflicting official identifier, stale evidence or unresolved temporal overlap is not stageable. All hierarchy rows remain `routable=false` until later batches establish local body, ward/office and routing evidence.

## Required validation before Batch 1 closure

- exactly one staged Maharashtra state record;
- duplicate code and duplicate normalized-name checks;
- all district parents resolve to state 27;
- all taluka parents resolve to a staged district;
- no missing identifiers or placeholder names;
- source counts compared, not forced;
- raw-file SHA-256 manifest complete;
- human review of every conflict and official rename;
- explicit statement that no records were automatically promoted.
