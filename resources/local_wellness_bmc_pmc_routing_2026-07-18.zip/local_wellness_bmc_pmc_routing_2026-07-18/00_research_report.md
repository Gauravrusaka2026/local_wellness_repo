# Local Wellness — BMC and PMC official-source routing research

**Research snapshot:** `2026-07-18T16:48:32+05:30` (Asia/Kolkata)  
**Municipalities:** Brihanmumbai Municipal Corporation (BMC) and Pune Municipal Corporation (PMC)  
**Categories:** 12 per municipality; 24 routing records  
**Production routing enabled:** **No**  
**Records automatically promoted:** **0**

## Executive finding

This package provides official-source evidence, published contacts, durable BMC role/department candidates, explicit asset-owner conditions, data gaps and import-ready disabled JSON. It does **not** provide a production-complete routing chain for any of the 24 municipality-category combinations.

BMC publishes a current generic complaint route through **1916** and **MARG**, and its 2026 Civic Diary supplies extensive ward and department-office contacts. However, a current BMC administration page says there are **24 administrative wards**, while the 2026 Civic Diary and current Assistant Commissioner directory publish **26 ward-office labels**, adding K/North and P/East. P/East is also published without a landline and with P/North's mailbox. This conflict, the absence of authoritative ward-location resolution, lack of current public category codes/first-response roles and missing automation approval prevent activation.

PMC publishes a current generic toll-free contact and a link to PMC CARE, and the Pune district site confirms PMC headquarters. But the current official ward-contact page exposes no rows, the officer directory says data is unavailable, reviewed department pages expose no usable responsibility/contact data, the available PMC CARE workflow booklet is from 2016, and the linked PMC CARE endpoint returned HTTP 502 during retrieval. No numeric ward identifiers were inferred.

## Package sections

### A. Source registry

`A_source_registry.csv` contains 24 official-source observations with publisher, exact URL, publication/source date where available, retrieval timestamp, extraction method, status, PDF page/section and hashes for downloaded evidence.

### B. Municipality and ward coverage

`B_municipality_ward_coverage.csv` contains 28 rows: two municipality-level rows plus 26 BMC published ward-office labels. There are no inferred PMC ward rows. All records are non-routable.

### C. Departments

`C_departments.csv` contains 13 records. BMC department names and HOD structures are supported by current official sources; all integration codes are explicitly Local Wellness internal keys, not official municipal codes. The only PMC functional-unit record is the stale historical Feedback Management Cell entry.

### D. Durable officer roles

`D_durable_officer_roles.csv` contains 16 durable roles and no officer names. BMC roles are separated from changing occupants. PMC role evidence is stale/incomplete.

### E. Offices and contacts

`E_offices_contacts.csv` contains 48 published contacts. It distinguishes public office contacts, verified generic complaint intake, emergency contacts and uncertain/stale PMC intake evidence. Every record has `automated_delivery_approved=false`.

BMC contact coverage includes all 26 ward-office labels published in the 2026 Civic Diary, but it is not production-complete: P/East lacks a phone and duplicates P/North's mailbox; K/North and P/East are implicated in the ward-structure conflict; R/North's raw published postcode is quarantined for review. A published phone or email is not treated as proof of complaint-intake or automated-delivery authority.

### F. Category routing matrix

`F_category_routing_matrix.csv` contains 24 disabled routing records. Local Wellness category codes are marked internal; official category codes/names remain null because no current public taxonomy was verified. Exact first-response roles are null where official sources do not establish them.

| Category | BMC candidate chain | PMC department | Minimum material blocker (BMC) | Decision |
|---|---|---|---|---|
| Garbage dump | Solid Waste Management Department | Not verified | Current official category code; complete first-response role/unit; verified address-to-ward lookup; explicit automated-delivery approval. | Disabled in both |
| Missed sweeping | Solid Waste Management Department | Not verified | Current official category code; ward/beat first-response role; official sweeping-beat ownership; automated-delivery approval. | Disabled in both |
| Pothole | Roads & Traffic Department | Not verified | Authoritative road-segment ownership layer/crosswalk; current official BMC category code and first-response role; external-owner delivery approval. | Disabled in both |
| Blocked drain | Storm Water Drainage Department | Not verified | Drain/sewer asset type and owner; asset-to-ward crosswalk; current first-response role; current category taxonomy and automated-delivery approval. | Disabled in both |
| Sewage overflow | Sewerage Operations Department | Not verified | Sewer asset ownership/identifier; exact current first-response role and SLA; category code; automated-delivery approval. | Disabled in both |
| Water leakage | Hydraulic Engineer Department | Not verified | Water-network owner/asset identifier; current first-response role; category taxonomy; automated-delivery approval. | Disabled in both |
| Broken streetlight | Mechanical & Electrical Department | Not verified | Streetlight pole identifier and ownership/operator layer; live contractor assignment; current first-response role; automated-delivery approval. | Disabled in both |
| Open manhole | Asset classification required | Not verified | Asset type/owner and identifier; safe verified temporary-security responsibility; current first-response roles for each asset class; automation approval. | Disabled in both |
| Mosquito breeding | Public Health Department | Not verified | Current ward pest-control first-response role/contact; current category code/SLA; property-jurisdiction rules; automation approval. | Disabled in both |
| Illegal construction | Building Proposals Department | Not verified | Official parcel/building-to-planning-authority and region crosswalk; enforcement first-response role; category code/SLA; delivery approval. | Disabled in both |
| Encroachment | Removal of Encroachment | Not verified | Official land-owner/region crosswalk; current regional assignment/vacancy confirmation; category code/SLA; automation approval. | Disabled in both |
| Fallen tree | Gardens / Tree Authority | Not verified | Tree/land ownership and ward crosswalk; current field first-response role/contact; priority/SLA rules; automation approval. | Disabled in both |

### G. Required category fields

`G_required_category_fields.csv` keeps official required fields, media limits and accuracy requirements null. Engineering proposals are stored separately and marked `placeholder`; they must not be represented as official municipal requirements.

### H. Data conflicts and gaps

`H_data_conflicts_gaps.csv` contains 37 structural and category-specific blockers. Every category remains disabled.

### I. Import-ready JSON

`I_import_ready.json` contains exactly 24 normalized objects using the requested shape plus explicit safety/provenance extensions. `productionRoutingEnabled=false`, every `autoRouteEnabled=false`, and all proposed fields are separately labeled placeholder engineering data.

## Municipality-specific routing posture

### BMC

Safe evidence for non-routable staging includes the published ward-office contact directory, central 1916/MARG intake, current durable HOD titles and department-office contacts. It is not safe to automatically send complaints to ward or department mailboxes: no source authorizes Local Wellness automated delivery, the public MARG page does not expose current category/queue codes, and category-specific first-response roles are not established.

Asset-dependent routing must remain in review:

- Potholes require authoritative road-segment ownership before choosing BMC, PWD, MMRDA, MSRDC or NHAI/IHMCL.
- Blocked drains and open manholes require storm-water/sewer/road/utility asset classification.
- Water leaks require network ownership evidence before choosing BMC Hydraulic, MJP or another operator.
- Streetlights require pole/operator/road-owner evidence; MSEDCL customer care does not prove municipal streetlight ownership.
- Illegal construction requires parcel-to-planning-authority and regional-office evidence.
- Encroachment requires land/right-of-way ownership and regional scope.
- Fallen trees require land/tree/road/power ownership and an urgent hazard path.

### PMC

Only generic public contacts and an emergency control-room contact are stageable as non-routing references. No category can be assigned to a current official department, ward office, primary durable role or escalation role from the official material retrieved. PMC's generic helpline/CARE link must not be presented as proof of an internal department assignment.

## Categories that may share infrastructure but require separate rules

- Garbage dump and missed sweeping may share BMC Solid Waste Management escalation, but location/beat and issue semantics remain distinct.
- Blocked drain, sewage overflow and open manhole share an asset-classification gate, but storm-water, sanitary sewer and non-municipal utility chambers require different recipients.
- Pothole, water leakage, broken streetlight and open manhole all require owner evidence, but each uses a different asset registry and hazard model.
- Illegal construction and encroachment share jurisdiction/land-control checks, but planning enforcement and land/right-of-way enforcement are different chains.
- Fallen tree can share Disaster Management as an urgent fallback while retaining Gardens/Tree Authority as the municipal functional candidate.

## Minimum before activation

For **each BMC category**, obtain the current official MARG category/queue code, exact first-response role or internal queue, effective ward-location mapping, any required asset-owner crosswalk, current escalation/SLA and explicit delivery/API approval. Resolve the 24-versus-26 ward-office conflict and P/East contact anomaly first.

For **each PMC category**, obtain a current official numeric ward/region roster and boundaries, department responsibility directory, durable role hierarchy, ward/department office contacts, current PMC CARE taxonomy and escalation/SLA, a working verified intake endpoint, and explicit automated-delivery authority.

## Validation and promotion

`J_validation_report.csv` records 30 checks. Structural/file checks pass; BMC location-to-ward, PMC ward/department coverage, asset ownership and automated delivery are explicitly blocked. No record was automatically promoted, and no category is recommended for active routing.

## Evidence files

- `evidence/BMC_Civic_Diary_2026_relevant_extract.pdf` — relevant official pages retained; SHA-256 `dda8e319df5df6ec2a8a0d5cbd5593b8a85d0c24eb4ed908bf876110afb68eb0`.
- `evidence/PMC_CARE_Booklet_official.pdf` — complete official historical booklet; SHA-256 `c0a9bcfbbb1641cffb341839fa82a88aa412c8fb1187e7ca3bd999f52319b38f`.

## Status counts

- Source/fact records by status: {'source_verified': 111, 'conflicting': 23, 'stale': 10, 'unverified': 45, 'placeholder': 13}
- Routing records by status: {'unverified': 16, 'conflicting': 8}
- Contact records by status: {'source_verified': 44, 'conflicting': 2, 'unverified': 1, 'stale': 1}

**Explicit batch statement:** No records were automatically promoted. No category is production-routable from this package.
