# Promotion recommendation — BMC/PMC routing research

**Snapshot:** `2026-07-18T16:48:32+05:30`  
**Automatic promotions:** **0**  
**Active routing recommendation:** **Disable all 24 category routes**

## Safe to stage — non-routable reference data only

- Exact official source registry and downloaded evidence hashes.
- BMC published ward-office labels and contacts, preserving K/North/P/East and all anomalies/conflicts.
- BMC current durable HOD/ward-administration roles and department-office contacts.
- BMC 1916/MARG and Sewerage Operations helpline as human-operated official intake references.
- PMC headquarters and currently published generic contact as public references, not department assignments.
- PMC Control Room numbers as emergency-reference contacts from current PMRDA evidence.
- Conditional external-owner channels for PWD, MSEDCL, MMRDA, MSRDC, NHAI/IHMCL, Aaple Sarkar and MJP, with owner dependency preserved.

## Potentially safe after human review and new official evidence

- BMC ward-first routing after a dated master ward roster, official boundary/address resolver and P/East contact confirmation.
- BMC department routing after obtaining the current MARG taxonomy/internal queue or official role-to-category procedure.
- PMC generic intake fallback after confirming the production PMC CARE endpoint and current workflow.
- Asset-owner routing after integrating effective official ownership datasets and confirming receiving-channel authority.

## Conflicting

- BMC 24 administrative wards versus 26 published ward-office labels.
- P/East missing phone and duplicated P/North mailbox.
- Asset-dependent categories where multiple government owners may apply.

## Incomplete

- Current PMC numeric ward roster, boundaries, department directory, durable role chain and ward/department contacts.
- Category-specific first-response roles, escalation clocks and service levels for both municipalities.
- Current official category codes/names and required-field/media schemas.
- Explicit authorization for automated submission to any published email, phone or portal.

## Prohibited from routing

- All 24 records in `F_category_routing_matrix.csv` and `I_import_ready.json`.
- Any record with `placeholder`, `unverified`, `conflicting` or `stale` status.
- P/East ward contact until directly confirmed.
- Any inferred ward, department, officer, contact, geometry or asset owner.
- Any external utility/road-authority route without feature-level ownership evidence.

**Decision:** Stage evidence for research/QA only. Do not enable automatic or recommended complaint routing. No records were automatically promoted.
