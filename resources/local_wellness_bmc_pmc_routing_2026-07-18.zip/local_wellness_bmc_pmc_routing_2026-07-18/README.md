# Package contents

Generated `2026-07-18T16:48:32+05:30` in Asia/Kolkata.

- `00_research_report.md` — findings and activation blockers
- `A_source_registry.csv` — Section A
- `B_municipality_ward_coverage.csv` — Section B
- `C_departments.csv` — Section C
- `D_durable_officer_roles.csv` — Section D
- `E_offices_contacts.csv` — Section E
- `F_category_routing_matrix.csv` — Section F
- `G_required_category_fields.csv` — Section G
- `H_data_conflicts_gaps.csv` — Section H
- `I_import_ready.json` — Section I
- `J_validation_report.csv` — machine-readable validation
- `K_promotion_recommendation.md` — promotion decision
- `evidence/` — retained official PDF evidence
- `MANIFEST.sha256` — SHA-256 checksums

All CSV files are UTF-8. No category is enabled for production routing, and no record was automatically promoted.
