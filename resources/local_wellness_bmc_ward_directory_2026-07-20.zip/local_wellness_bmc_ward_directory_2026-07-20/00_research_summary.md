# Local Wellness - BMC ward-directory extraction

**Research snapshot:** `2026-07-20T11:26:11+05:30` (Asia/Kolkata)  
**Official landing page:** https://dm.mcgm.gov.in/ward-directory  
**Primary embedded/current combined directory:** https://dm.mcgm.gov.in/assets/pdf/Final%20updated%20Final%20Connect%20Diary%202021.07.07.2021.pdf  
**Directory source-as-of:** 2026-06-18 for the contact-directory sections only

## Scope

This package extracts the routing-relevant official municipal material from the BMC ward directory and current CONNECT 2026 directory: the 24 traditional ward sections, office addresses and phone strings, ward control rooms, Assistant Commissioner role mailboxes and assignment snapshots, zonal escalation contacts, central municipal controls, durable routing roles, and a disabled 12-category Local Wellness routing matrix.

It intentionally excludes political representatives, private suppliers, NGOs, hotels and other non-government contacts appearing in the disaster directory because they are not durable municipal complaint-routing recipients and may contain personal/non-production contact data.

## Record counts

- 24 traditional ward-section records
- 4 separately published operational subscopes: K/South, K/North, P/East and P/West
- 24 parent ward office/contact records
- 26 Assistant Commissioner assignment-scope observations (24 parent labels plus separate K/North and P/East operational assignments)
- 7 zonal DMC contact observations
- 13 central/department control contacts
- 25 durable role records
- 12 municipality-category routing templates
- 288 import JSON ward-category records
- 22 conflict/gap records
- 0 automatically promoted records

## What is complete

All 24 traditional ward sections have a published office address, main-office phone string and Assistant Commissioner role mailbox. Ward control-room strings and an Assistant Commissioner assignment snapshot are also present for each parent section, although F/South and T contain malformed/questionable raw phone values that were not corrected.

## Material conflicts

1. BMC Administration says 24 wards, while current directories publish additional or renamed operational scopes: K/South, K/North, P/East and P/West.
2. E Ward address/postcode differs between two official 2026 directories.
3. M/East has two official role-mailbox values: `ac.me@mcgm.gov.in` and `ac.meast@mcgm.gov.in`.
4. R/North postcode differs between CONNECT 2026 and the Civic Diary.
5. S and T zone headings conflict with the published zonal mailbox.
6. The primary PDF contains mixed-age material, so its online availability and 2026 title are not treated as proof that every row is current.

## Routing decision

No category is production routable. The ward directory establishes contacts and role presence, but does not expose current official complaint category codes, category-to-internal-queue mappings, SLAs, an effective address-to-ward resolver, asset-owner crosswalks, or explicit approval for Local Wellness to deliver complaints automatically to ward emails.

**No records were automatically promoted.**
