# BMC ward-directory promotion recommendation

**Batch verified:** 2026-07-20  
**Retrieved:** 2026-07-20T11:26:11+05:30

## Safe to stage, non-routably

- The 24 traditional BMC ward-section identifiers and names.
- Directly published ward-office addresses and main office phone strings, with raw values preserved.
- Directly published Assistant Commissioner role mailboxes, subject to the listed contact conflicts.
- 1916/MARG as a generic BMC complaint intake reference.
- Durable municipal role and department names.

## Potentially safe after human review

- Assistant Commissioner assignment snapshots, after comparison with an appointment/transfer/charge order.
- Ward control-room numbers, after telephone verification and correction evidence for F/South/T anomalies.
- K/North and P/East operational office contacts, after BMC confirms the effective ward/sub-office model.

## Conflicting

- K/East-K/South-K/North and P/North-P/East-P/West structure.
- E Ward address.
- M/East role mailbox.
- R/North postcode.
- S/T zonal escalation label/mailbox.

## Incomplete

- Ward boundaries or official location resolver.
- Category codes, first-response queues, escalation clocks and service levels.
- Asset ownership for roads, drains, sewers, water, streetlights, manholes, trees and land.
- Explicit approval for automated complaint delivery.

## Prohibited from routing

- All 288 category-by-ward JSON records.
- Any route depending on a conflicting operational scope.
- Any email/phone treated as an automated delivery endpoint merely because it is published.
- Any inferred correction to malformed phone/email/address data.

**Recommendation: stage as research/reference data only. Keep every category disabled. No records were automatically promoted.**
