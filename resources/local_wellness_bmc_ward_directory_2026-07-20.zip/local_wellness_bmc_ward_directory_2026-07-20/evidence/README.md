# Evidence access note

Primary official URL: https://dm.mcgm.gov.in/assets/pdf/Final%20updated%20Final%20Connect%20Diary%202021.07.07.2021.pdf

The official PDF was accessible for parsed-text review, but direct file download and page screenshots timed out in the execution environment. Therefore this package does not include the original PDF and does not claim a SHA-256 hash for it. Exact URLs, pages, retrieval time and extraction method are preserved in `A_source_registry.csv` and `L_access_log.csv`.
